package main

import (
	"fmt"

	"gopkg.in/godo.v2/glob"
)

func main() {

	patterninput := "**/packagefiles/*.*"
	pattern := []string{patterninput}
	files, _, err := glob.Glob(pattern)

	if err != nil {
		fmt.Println(err)
	}

	for _, file := range files {
		fmt.Println(file.Path)
		// if strings.HasSuffix(file.Path, "sub1.txt") {
		// 	t.Error("should have excluded a negated pattern")
		// }
	}
	//fmt.Println(fileset)

	// pattern := "testfiles/tex*.html"
	// matches, err := filepath.Glob(pattern)

	// if err != nil {
	// 	fmt.Println(err)
	// }

	// fmt.Println(matches)

	// search upper directory
	// upperDirPattern := "../*input*"

	// // you can specify directly the directory you want to search as well with the pattern
	// // for example, /usr/files/*input*

	// matches, err = filepath.Glob(upperDirPattern)

	// if err != nil {
	// 	fmt.Println(err)
	// }

	// fmt.Println(matches)
}
