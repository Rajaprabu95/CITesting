package main

import (
	"fmt"

	"gopkg.in/godo.v2/glob"
)

func FilesMatchingPattern(pattern string) []string {

	filteredfiles := []string{}
	files, _, err := glob.Glob([]string{pattern})

	if err != nil {
		fmt.Println(err)
	}

	for _, file := range files {
		fmt.Println(file.Path)
		if file.Path != "." {
			filteredfiles = append(filteredfiles, file.Path)
		}

	}
	return filteredfiles
}
